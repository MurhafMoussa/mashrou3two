package com.example.mashrou3two

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
